class Greet {
	public static void main(String[] args) {
    Tui tui = new Tui();

    int key;

    boolean quit=false;

    int x=1,y=1;
    int xi=1,yi=0;
    int px=x,py=y;

    tui.hideCursor();
		tui.clrscr();

    while(!quit) {
      tui.gotoxy(x,y); System.out.print('X');

      if(tui.kbhit()!=0) {
        key=tui.getch();
        switch(key) {
          case 27: quit=true; break;
          case 'w': xi= 0; yi=-1; break;
          case 's': xi= 0; yi=+1; break;
          case 'a': xi=-1; yi= 0; break;
          case 'd': xi=+1; yi= 0; break;
          default: break;
        }
      }

      x+=xi;
      y+=yi;

      if(x<1) x=80;
      if(y<1) y=24;
      if(x>80) x=1;
      if(y>24) y=1;


      tui.gotoxy(px,py); System.out.print(' ');
      px=x; py=y;
    }

    tui.showCursor();
	}
}
