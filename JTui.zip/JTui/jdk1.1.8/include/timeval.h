/*
 * @(#)timeval.h	1.9 01/12/10
 *
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

#ifndef	_TIMEVAL_H_
#define	_TIMEVAL_H_

#include "timeval_md.h"

typedef timeval_t Timeout;

#endif	/* !_TIMEVAL_H_ */
