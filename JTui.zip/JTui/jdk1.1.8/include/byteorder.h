/*
 * @(#)byteorder.h	1.7 01/12/10
 *
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

#ifndef	_BYTEORDER_H_
#define	_BYTEORDER_H_

#include "byteorder_md.h"

#endif	/* !_BYTEORDER_H_ */
