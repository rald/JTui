/*
 * @(#)oobj_md.h	1.10 01/12/10
 *
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

/*-
 * Win32 dependent oobj defines
 */

#ifndef _WIN32_OOBJ_MD_H_
#define _WIN32_OOBJ_MD_H_

/* This space intentionally left blank */

#endif /* !_WIN32_OOBJ_MD_H_ */
