/*
 * @(#)config.h	1.9 01/12/10
 *
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

/*
 * Configuration parameters
 */

#ifndef _CONFIG_H_
#define _CONFIG_H_

#define MaxLocalVars 255

#endif /* !_CONFIG_H_ */
